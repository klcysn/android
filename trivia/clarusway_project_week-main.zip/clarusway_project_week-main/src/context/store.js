export const initialState = {
    questions: [],
    score: 0
}